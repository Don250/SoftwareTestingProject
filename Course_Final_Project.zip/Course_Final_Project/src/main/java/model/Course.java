package model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="coursez")
public class Course {
    @Id
    private String courseId;
    private String CourseName;
    private String courseCredits;

    public Course() {
    }

    public String getCourseId() {
        return courseId;
    }

    public String getCourseName() {
        return CourseName;
    }

    public String getCourseCredits() {
        return courseCredits;
    }

    public Course(String courseId, String courseName, String courseCredits) {
        this.courseId = courseId;
        CourseName = courseName;
        this.courseCredits = courseCredits;

    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public void setCourseName(String courseName) {
        CourseName = courseName;
    }

    public void setCourseCredits(String courseCredits) {
        this.courseCredits = courseCredits;
    }
}
