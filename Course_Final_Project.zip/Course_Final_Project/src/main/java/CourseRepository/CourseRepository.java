package CourseRepository;

import model.Course;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.List;

public class CourseRepository {
    public boolean saveCouse(Course course) {
        boolean isSaved=false;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.save(course);
            session.getTransaction().commit();
            session.close();
            isSaved=true;
        }catch (Exception e)
        {
            isSaved=false;
        }

        return isSaved;
    }
    public List<Course> findAll(){
        Session session = HibernateUtil.getSessionFactory().openSession();
        Query query = session.createQuery("from Course ");
        List<Course> allCourses = query.list();
        session.close();
        return allCourses;

    }
    public boolean deletCourse(Course course){
        boolean saved=false;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.delete(course);
            session.getTransaction().commit();
            session.close();
            saved=true;

        }catch (Exception e)
        {
            saved=false;
        }
        return saved;

    }

    public boolean updateCourse(Course course){
        boolean isUpdated=false;
        try {
            Session session =HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.update(course);
            session.getTransaction();
            session.close();
            isUpdated=true;
        }catch (Exception e)
        {
            isUpdated=false;
        }
        return isUpdated;
    }

    public Course findByCourseId(String courseId){

        Session session =HibernateUtil.getSessionFactory().openSession();
        return session.get(Course.class,courseId);
    }
//    public List<Course> findByallCourse(){
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        Query query = session.createQuery("from Course ");
//        List<Course> ca = query.list();
//        session.close();
//        return ca;
//
//    }
}
