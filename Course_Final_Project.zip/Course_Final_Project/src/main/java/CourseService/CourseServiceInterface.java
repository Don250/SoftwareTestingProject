package CourseService;

import model.Course;

import java.util.List;

public interface CourseServiceInterface {
    public boolean saveCourse(Course course);
    public List<Course> listAllCourse();
    public boolean deleteCourse(Course course);

    public boolean updateCourse(Course course);

    public Course getCourse(String courseId);
}
