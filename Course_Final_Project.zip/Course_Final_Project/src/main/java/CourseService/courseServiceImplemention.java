package CourseService;


import CourseRepository.CourseRepository;
import model.Course;

import java.util.List;

public class courseServiceImplemention implements CourseServiceInterface{
private CourseRepository courseRepository = new CourseRepository();
    @Override
    public boolean saveCourse(Course course) {
        return  courseRepository.saveCouse(course);
    }

    @Override
    public List<Course> listAllCourse() {
        List<Course>courseList= courseRepository.findAll();
        return courseList;
    }

    @Override
    public boolean deleteCourse(Course course) {
        return courseRepository.deletCourse(course);
    }

    @Override
    public boolean updateCourse(Course course) {

        return courseRepository.updateCourse(course);
    }

    @Override
    public Course getCourse(String courseId) {
        Course course = courseRepository.findByCourseId(courseId);

        return course;
    }
}
