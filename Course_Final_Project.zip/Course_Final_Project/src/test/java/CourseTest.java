
import CourseService.CourseServiceInterface;
import CourseService.courseServiceImplemention;
import model.Course;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;

import java.util.List;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class CourseTest {
    private CourseServiceInterface courseServiceInterface = new courseServiceImplemention();

    @Test
    @Order(1)

    public void saveCourse() {
        Course cors = new Course();
        cors.setCourseId("SENG2546");
        cors.setCourseName("TOC");
        cors.setCourseCredits("5");


        boolean cssaved = courseServiceInterface.saveCourse(cors);
        Assert.assertEquals(true, cssaved);


        Course std = new Course();
        std.setCourseId("NSY23123");
        std.setCourseName("Linux");
        std.setCourseCredits("3");

        boolean stsaved = courseServiceInterface.saveCourse(std);
        Assert.assertEquals(true, stsaved);


    }

        @Test
    @Order(2)

    public void savedCoursez(){
        Course stdnt = new Course();
        stdnt.setCourseId("NSY222");
        stdnt.setCourseName("Dot net");
        stdnt.setCourseCredits("3");

        boolean studentsaved =courseServiceInterface.saveCourse(stdnt);
        Assert.assertEquals(false,studentsaved);





    }
    @Test
    @Order(3)

    public void updateCourse() {

        Course std = new Course();
        std.setCourseId("NSY23123");
        std.setCourseName("JAVA");
        std.setCourseCredits("4");

        boolean stsaved = courseServiceInterface.updateCourse(std);
        Assert.assertEquals(true, stsaved);


    }

        @Test
    @Order(4)

    public void updateCourses(){
            Course std = new Course();
            std.setCourseId("NSY23123");
            std.setCourseName("JAVA");
            std.setCourseCredits("4");

            boolean stsaved = courseServiceInterface.updateCourse(std);

            Assert.assertEquals(false,stsaved);

    }
    @Test
    @Order(5)
    public void findByCourseId() {
        Course findStud_id = courseServiceInterface.getCourse("NSY23123");
        Assert.assertEquals("NSY23123", findStud_id.getCourseId());

    }
    @Test
    @Order(6)
    public void findByCourseIds() {
        Course findStud_id = courseServiceInterface.getCourse("NSY23123");
        Assertions.assertNotEquals("NSY23123", findStud_id.getCourseId());

    }
    @Test
    @Order(6)
    public void findByAllCoursez() {
        List<Course> courseListList = courseServiceInterface.listAllCourse();
        Assert.assertEquals(0,courseListList.size());

    }


    @Test
    @Order(7)
    public void findByAllCourses() {
        List<Course> courseList = courseServiceInterface.listAllCourse();
        Assertions.assertNotEquals(0, courseList.size());


    }


    @Test
    @Order(8)
    public void deleteCourse() {
        Course course = new Course();
        course.setCourseId("23123");
        boolean studentdeleted = courseServiceInterface.deleteCourse(course);
        Assert.assertEquals(true, studentdeleted);


    }

    @Test
    @Order(9)
    public void deleCorsez() {
        Course cs = new Course();
        cs.setCourseId("23123");
        boolean studentdeleted = courseServiceInterface.deleteCourse(cs);
        Assert.assertEquals(false, studentdeleted);


    }
}

