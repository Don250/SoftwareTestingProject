import dao.CourseDao;
import model.Course;
import org.junit.jupiter.api.*;

import java.util.List;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestCreateUpdate0001 {
    private  CourseDao dao = new CourseDao();

    @Test
    @Order(1)
    public void saveCourse(){
        Course course = new Course("0001","java",4);
        CourseDao dao = new CourseDao();
        String id = dao.registerCourse(course);
        Assertions.assertTrue(id.equals("0001"));
    }
    @Test
    @Order(2)
    public  void updateCourse(){
        Course course = new Course();
        course.setCourseId("0001");
        course.setName("Software Engineering");
        course.setCredit(3);
        String id =dao.updateCourse(course);
        Assertions.assertTrue(id.equals("0001"));



    }
    @Test
    @Order(2)
    public void testValidityCredit(){
        Course course = new Course("0004","java",4);
        CourseDao dao = new CourseDao();
        boolean daoCheck = dao.registerCourseWithValidCredit(course);
        Assertions.assertTrue(daoCheck);
    }
    @Test
    @Order(3)
    public void testNonValidityCredit(){
        Course course = new Course("0001","java",6);
        CourseDao dao = new CourseDao();
        boolean daoCheck = dao.registerCourseWithValidCredit(course);
        Assertions.assertFalse(daoCheck);
    }
    @Test
    @Order(4)
    public void findByAllCourse(){
        List<Course>courseList = dao.allCourses();
        Assertions.assertNotEquals(1,courseList);


    }

}
