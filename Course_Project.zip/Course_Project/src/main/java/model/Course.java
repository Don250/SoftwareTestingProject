package model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Course {
    @Id
    private String courseId;
    private String name;
    private Integer credit;

    public Course() {
    }
    public Course(String courseId) {
        this.courseId = courseId;
    }
    public Course(String courseId, String name, Integer credit) {
        this.courseId = courseId;
        this.name = name;
        this.credit = credit;
    }
    // getters and setters


    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCredit() {
        return credit;
    }

    public void setCredit(Integer credit) {
        this.credit = credit;
    }
    public Boolean checkCredit(){
        if(credit>=1 && credit <=4){
            return true;
        }
        return false;
    }
}
