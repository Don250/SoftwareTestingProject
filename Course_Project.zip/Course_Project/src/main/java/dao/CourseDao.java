package dao;

import model.Course;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class CourseDao {
    // CRUD
    public String registerCourse(Course course){
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
/**
 *  if in model class your id has Integer kindly
 *  use int id = (int)ss.save(course)
 */
        String courseId = (String)ss.save(course);
        tr.commit();
        ss.close();
        return courseId;
    }
    public String updateCourse(Course course){
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        Course courseToUpdate = findById(course);
        if(courseToUpdate !=null){
            courseToUpdate.setCredit(course.getCredit());
            courseToUpdate.setName(course.getName());
            ss.update(courseToUpdate);
        }
        tr.commit();
        ss.close();
        return courseToUpdate.getCourseId();
    }
    public Course findById(Course course){
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Course cour = ss.get(Course.class,course.getCourseId());
        ss.close();
        return cour;
    }

    public void deleteCourse(Course course){
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr =ss.beginTransaction();
        Course courseToDelete = findById(course);
        if(courseToDelete !=null){
            ss.delete(courseToDelete);
        }
        ss.close();
    }

    public List<Course> allCourses(){
        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<Course> courseList = ss.createQuery(" from Course ").list();
        ss.close();
        return courseList;
    }

    public Boolean registerCourseWithValidCredit(Course course){
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        boolean check = false;
        if(course.getCredit()>=1 && course.getCredit()<=4){
            check = true;
            ss.save(course);
        }
        tr.commit();
        ss.close();
        return check;
    }

}
