import model.Student;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import serviceInterface.StudentServiceImplementaiton;
import serviceInterface.StudentserviceInterface;

import java.util.List;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class StudentTest {
    private StudentserviceInterface studentserviceInterface = new StudentServiceImplementaiton();
    @Test
    @Order(1)

    public void saveStudent(){
        Student stdnt = new Student();
        stdnt.setStudentId("23123");
        stdnt.setFirstName("Munyeshyaka");
        stdnt.setLastName("Donatien");
        stdnt.setPhoneNumber("+250780421476");
        stdnt.setEmail("shyakadon@gmail.com");
        stdnt.setPassword("Dongate@123");
        boolean studentsaved =studentserviceInterface.saveStudent(stdnt);
        Assert.assertEquals(true,studentsaved);


        Student std = new Student();
        std.setStudentId("22166");
        std.setFirstName("Hakizimana");
        std.setLastName("Claude");
        std.setPhoneNumber("+250780466666");
        std.setEmail("hakizamna@gmail.com");
        std.setPassword("hakiz@123");
        boolean stsaved=studentserviceInterface.saveStudent(std);
        Assert.assertEquals(true,stsaved);




    }
    @Test
    @Order(2)

    public void savedStudent(){
        Student stdnt = new Student();
        stdnt.setStudentId("23123");
        stdnt.setFirstName("Munyeshyaka");
        stdnt.setLastName("Donatien");
        stdnt.setPhoneNumber("+250780421476");
        stdnt.setEmail("shyakadon@gmail.com");
        stdnt.setPassword("Dongate@123");
        boolean studentsaved =studentserviceInterface.saveStudent(stdnt);
        Assert.assertEquals(false,studentsaved);

        Student std = new Student();
        std.setStudentId("22166");
        std.setFirstName("Hakizimana");
        std.setLastName("Claude");
        std.setPhoneNumber("+250780466666");
        std.setEmail("hakizamna@gmail.com");
        std.setPassword("hakiz@123");
        boolean stsaved=studentserviceInterface.saveStudent(std);

        Assert.assertEquals(false,stsaved);



    }
    @Test
    @Order(3)

    public void updateStudent(){
        Student student = new Student();
        student.setStudentId("23123");
        student.setFirstName("Niyonzima");
        student.setLastName("Fredy");
        student.setPhoneNumber("+250729992999");
        student.setEmail("fredy@gmail.com");
        student.setPassword("fr534662");
        boolean studentUpdate = studentserviceInterface.upadateStudent(student);
        studentserviceInterface.upadateStudent(student);
        Assert.assertEquals(true,studentUpdate);


    }
    @Test
    @Order(4)

    public void updateStudents(){
        Student student = new Student();
        student.setStudentId("23123");
        student.setFirstName("Niyonzima");
        student.setLastName("Fredy");
        student.setPhoneNumber("+250729992999");
        student.setEmail("fredy@gmail.com");
        student.setPassword("fr534662");
        boolean studentUpdate = studentserviceInterface.upadateStudent(student);
        studentserviceInterface.upadateStudent(student);

        Assert.assertEquals(false,studentUpdate);

    }
    @Test
    @Order(5)
    public void findByStudentId(){
        Student findStud_id = studentserviceInterface.findByStudentId("23123");
        Assert.assertEquals("23123",findStud_id.getStudentId());

    }

    @Test
    @Order(7)
    public void findByAllStudent(){
        List<Student> studentList = studentserviceInterface.findAllStudent();
        Assert.assertEquals(0,studentList.size());


    }

    @Test
    @Order(8)
    public void findByAllStudents(){
        List<Student> studentList = studentserviceInterface.findAllStudent();
        Assert.assertEquals(0,studentList.size());

    }

    @Test
    @Order(9)
    public void deleteStudent(){
        Student student = new Student();
        student.setStudentId("23123");
        boolean studentdeleted= studentserviceInterface.deleteStudent(student);
        Assert.assertEquals(true,studentdeleted);


    }

    @Test
    @Order(10)
    public void deleteStudentz(){
        Student student = new Student();
        student.setStudentId("23123");
        boolean studentdeleted= studentserviceInterface.deleteStudent(student);
        Assert.assertEquals(false,studentdeleted);


    }
    @Test
    @Order(10)
    public void deleteStudents(){
        Student student = new Student();
        student.setStudentId("23123");
        boolean studentdeleted= studentserviceInterface.deleteStudent(student);
        Assert.assertEquals(false,studentdeleted);

    }

}

