package serviceInterface;

import model.Student;

import java.util.List;

public interface StudentserviceInterface  {

    public boolean saveStudent(Student student);
    public List<Student>findAllStudent();
    public boolean deleteStudent(Student student);
    public boolean upadateStudent(Student student);
    public Student findByStudentId(String studentId);
}
