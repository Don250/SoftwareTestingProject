package serviceInterface;

import model.Student;
import studentRepository.Student_Repository;

import java.util.List;

public class StudentServiceImplementaiton implements StudentserviceInterface {
    Student_Repository studentRepository = new Student_Repository();
    @Override
    public boolean saveStudent(Student student) {
        return  studentRepository.saveStudent(student);

    }

    @Override
    public List<Student> findAllStudent() {
        List<Student> studentList = studentRepository.findAllStudent();

        return studentList;
    }

    @Override
    public boolean deleteStudent(Student student) {

        return studentRepository.deleteStudent(student);
    }

    @Override
    public boolean upadateStudent(Student student) {
        return studentRepository.updateStudent(student);
    }

    @Override
    public Student findByStudentId(String studentId) {
        Student student = studentRepository.findByStudentId(studentId);
        return student;
    }
}
