package studentRepository;

import model.Student;
import org.hibernate.Session;

import javax.persistence.Query;
import java.util.List;

public class Student_Repository {
    public boolean saveStudent(Student student){
        boolean isSaved =false;
                try{
                    Session session=HibernateUtil.getSessionFactory().openSession();
                    session.beginTransaction();
                    session.save(student);
                    session.getTransaction().commit();
                    session.close();
                    isSaved=true;
                }catch (Exception e){
                    isSaved=false;

                }
                return  isSaved;

    }
    public  boolean updateStudent(Student student){
        boolean isUpdate=false;
        try {
            Session session = HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.update(student);
            session.getTransaction().commit();
            isUpdate = true;
        }catch (Exception e){

            isUpdate=false;
        }
        return isUpdate;
    }

    public Student findByStudentId(String studentId){
        Session session = HibernateUtil.getSessionFactory().openSession();
        return session.get(Student.class,studentId);

    }
    public List<Student>findAllStudent(){
        Session session =HibernateUtil.getSessionFactory().openSession();
        Query query =session.createQuery("from Student");
        List<Student> studentList=  query.getResultList();
                session.close();
                return studentList;
    }
    public boolean deleteStudent(Student student){
        boolean isDeleted=false;
        try{
            Session session =HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.delete(student);
            session.getTransaction().commit();
            session.close();
            isDeleted=true;

        }catch (Exception exception){
            isDeleted=false;
        }


return isDeleted;
    }
}
