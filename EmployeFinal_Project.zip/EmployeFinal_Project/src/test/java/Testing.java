import model.Employee;
import org.junit.Assert;
import service.ServiceImplementation;
import service.ServiceInterface;


import java.util.List;

public class Testing {
    private ServiceInterface serviceInterface = new ServiceImplementation();
   @org.junit.jupiter.api.Test

    public  void save(){
       Employee employee = new Employee();
       employee.setEmpId("435456");
       employee.setFirstEmp_name("Munyeshyaka");
       employee.setLastEmp_name("Donatien");
       employee.setEmp_phoneNo("0722777277");
       employee.setEmp_Email("shyakadon@gmail.com");
       employee.setEmp_password("dongate@1445");
       boolean saved =serviceInterface.save(employee);
       Assert.assertEquals(true,saved);


       Employee empl = new Employee();
       empl.setEmpId("333444");
       empl .setFirstEmp_name("Turinayo");
       empl .setLastEmp_name("David");
       empl .setEmp_phoneNo("0788884454");
       empl .setEmp_Email("turin@gmail.com");
       empl .setEmp_password("tur@65765");
       boolean saved1 =serviceInterface.save(empl);
       Assert.assertEquals(true,saved1);

    }
    @org.junit.jupiter.api.Test
    public void update(){
        Employee empl1 = new Employee();
        empl1.setEmpId("333444");
        empl1 .setFirstEmp_name("Ndagiri");
        empl1 .setLastEmp_name("Engineer");
        empl1 .setEmp_phoneNo("0784747333");
        empl1 .setEmp_Email("ndagij@gmail.com");
        empl1 .setEmp_password("64757gtt");
        boolean updated =serviceInterface.update(empl1);
        Assert.assertEquals(true,updated);

    }
    @org.junit.jupiter.api.Test
    public  void findByAll(){
        List<Employee> employeeList = serviceInterface.findALL();
        Assert.assertEquals(2,employeeList.size());

    }
    @org.junit.jupiter.api.Test
    public  void findById(){
      Employee employee = new Employee();
       employee = serviceInterface.findById("333444");


    }
    @org.junit.jupiter.api.Test
    public void delete(){
       Employee employee = new Employee();
       boolean employ = serviceInterface.delete(employee);
       Assert.assertEquals(true,employ);
    }




}
