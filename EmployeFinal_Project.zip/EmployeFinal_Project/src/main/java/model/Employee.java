package model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employes")
public class Employee {
    @Id
    private String empId;
    private String firstEmp_name;
    private String lastEmp_name;
    private String emp_salary;
    private String  emp_phoneNo;
    private String emp_Email;
    private String emp_password;

    public Employee() {
    }

    public Employee(String empId, String firstEmp_name, String lastEmp_name, String emp_salary, String emp_phoneNo, String emp_Email, String emp_password) {
        this.empId = empId;
        this.firstEmp_name = firstEmp_name;
        this.lastEmp_name = lastEmp_name;
        this.emp_salary = emp_salary;
        this.emp_phoneNo = emp_phoneNo;
        this.emp_Email = emp_Email;
        this.emp_password = emp_password;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getFirstEmp_name() {
        return firstEmp_name;
    }

    public void setFirstEmp_name(String firstEmp_name) {
        this.firstEmp_name = firstEmp_name;
    }

    public String getLastEmp_name() {
        return lastEmp_name;
    }

    public void setLastEmp_name(String lastEmp_name) {
        this.lastEmp_name = lastEmp_name;
    }

    public String getEmp_salary() {
        return emp_salary;
    }

    public void setEmp_salary(String emp_salary) {
        this.emp_salary = emp_salary;
    }

    public String getEmp_phoneNo() {
        return emp_phoneNo;
    }

    public void setEmp_phoneNo(String emp_phoneNo) {
        this.emp_phoneNo = emp_phoneNo;
    }

    public String getEmp_Email() {
        return emp_Email;
    }

    public void setEmp_Email(String emp_Email) {
        this.emp_Email = emp_Email;
    }

    public String getEmp_password() {
        return emp_password;
    }

    public void setEmp_password(String emp_password) {
        this.emp_password = emp_password;
    }
}
