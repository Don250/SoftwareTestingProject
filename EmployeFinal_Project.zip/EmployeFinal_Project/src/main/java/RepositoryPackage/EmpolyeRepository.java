package RepositoryPackage;

import model.Employee;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.persistence.Query;
import java.util.List;

public class EmpolyeRepository {
    public boolean save(Employee employee){
        boolean emp = false;
        Session session =HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.save(employee);
        tx.commit();
        session.close();
        emp=true;
        return  true;
    }
    public List<Employee> findALL(){
        Session session = HibernateUtil.getSessionFactory().openSession();
        Query query =session.createQuery("from Employee");
        List<Employee>employeeList = query.getResultList();
        session.close();
        return  employeeList;

    }
    public boolean update(Employee employee){
        boolean updateemp = false;
        Session session =HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.update(employee);
        session.close();
        return  true;
    }
    public Employee findById(String  empId){
        Session session =HibernateUtil.getSessionFactory().openSession();
        Employee employee = session.get(Employee.class,empId);
        return  employee;


    }
    public boolean dataDeleted(Employee employee){
        boolean deleted = false;
        Session  session =HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        session.delete(employee);
        session.getTransaction().commit();
        session.close();
        deleted=true;
        return deleted;

    }



}
