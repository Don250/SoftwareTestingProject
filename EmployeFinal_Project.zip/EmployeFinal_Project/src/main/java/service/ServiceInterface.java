package service;

import model.Employee;

import java.util.List;

public interface ServiceInterface {
    public  boolean save(Employee employee);
    public List<Employee> findALL();
    boolean update(Employee employee);
    public  Employee findById(String empId);
    public boolean delete(  Employee employee);

}
