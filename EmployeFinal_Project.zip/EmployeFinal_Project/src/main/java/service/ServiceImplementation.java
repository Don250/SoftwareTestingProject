package service;

import RepositoryPackage.EmpolyeRepository;
import model.Employee;

import java.util.List;

public class ServiceImplementation implements ServiceInterface{
    private EmpolyeRepository empolyeRepository = new EmpolyeRepository();
    @Override
    public boolean save(Employee employee) {

        return empolyeRepository.save(employee);
    }

    @Override
    public List<Employee> findALL() {

        return empolyeRepository.findALL();
    }

    @Override
    public boolean update(Employee employee) {
       boolean rs= empolyeRepository.update(employee);
       if(rs){
           return true;
       }
        return false;
    }

    @Override
    public Employee findById(String empId) {
        return empolyeRepository.findById(empId);
    }

    @Override
public  boolean delete(Employee employee){
        boolean delet = false;
        empolyeRepository.dataDeleted(employee);
        delet=true;
        return delet;

}
}
