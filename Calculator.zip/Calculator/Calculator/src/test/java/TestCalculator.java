import org.junit.*;

public class TestCalculator {
    private calculatorInterface calculatorInterface=new calculator();
    @Test
  public void testAddition(){
        int a =9;
        int b =10;
        int sum =calculatorInterface.addition(a , b);
        Assert.assertEquals(19 ,sum);
    }
    @Test
    public void testMultiplication(){
        int a =20;
        int b =2;
        int sum =calculatorInterface.multiplication(a ,b);
       Assert.assertEquals(40 ,sum);
    }
    @Test
    public void testDivision() throws Exception{
        int a =20;
        int b =2;
        int sum =calculatorInterface.division(a ,b);
        Assert.assertEquals(10 ,sum);
    }

    @Test
    public void testSubtraction(){
        int a =20;
        int b =2;
        int sum =calculatorInterface.subtraction(a ,b);
        Assert.assertEquals(18 ,sum);
    }
   // @Ignore
    @Test(expected = Exception.class)
    public void netgativeDivisionTest()throws Exception{
        int a=9;
        int b=0;
        calculatorInterface.division(a, b);
    }
    @Before
    public void before(){
        System.out.println("Hello world before");
    }

    @After
    public void after(){
        System.out.println("Hello world after");
    }
}
